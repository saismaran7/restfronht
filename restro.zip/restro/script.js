 
 document.addEventListener('DOMContentLoaded', function() {
     const form = document.getElementById('order-form');
 
     
     form.onsubmit = function(event) {
        
         console.log('Form submitted');
         
         form.reset();
     }
 });